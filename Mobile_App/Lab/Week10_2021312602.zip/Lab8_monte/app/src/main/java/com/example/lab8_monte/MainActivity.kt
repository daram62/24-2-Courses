package com.example.lab8_monte

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var textView: TextView
    private lateinit var startButton: Button
    private lateinit var toggleSwitch: Switch
    private var isRunning = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)
        startButton = findViewById(R.id.button)
        toggleSwitch = findViewById(R.id.switch1)

        // Toggle switch to pause or resume the simulation
        toggleSwitch.setOnCheckedChangeListener { _, isChecked ->
            isRunning = isChecked
        }

        // Start the simulation when the button is clicked
        startButton.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                textView.text = longTask()
            }
        }
    }

    // Function to perform the Monte Carlo simulation
    private suspend fun longTask(): String = withContext(Dispatchers.Default) {
        var totalCount = 0
        var innerCount = 0

        for (bigLoop in 1..100) { // 100 steps, each with 1,000,000 iterations
            for (smallLoop in 1..1_000_000) {
                // Pause the simulation if the switch is off
                if (!isRunning) {
                    delay(100)
                    continue
                }

                // Generate random x and y values
                val x = Math.random().toFloat()
                val y = Math.random().toFloat()

                // Check if the point (x, y) is inside the unit circle
                if (x * x + y * y <= 1) innerCount++
                totalCount++
            }

            // Calculate the current estimation of Pi
            val currentValue = (innerCount.toDouble() / totalCount) * 4.0

            // Update the UI with the intermediate progress
            withContext(Dispatchers.Main) {
                textView.text = "Done ${bigLoop}%...\n" +
                        "current estimation: ${String.format("%.6f", currentValue)}"
            }
        }

        // Final result after the simulation completes
        val lastValue = (innerCount.toDouble() / totalCount) * 4.0
        return@withContext "Done!\nEstimation: ${String.format("%.6f", lastValue)}"
    }
}